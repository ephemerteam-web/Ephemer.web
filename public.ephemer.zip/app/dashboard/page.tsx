'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

export default function DashboardPage() {
  // On stocke les infos de l'utilisateur connecté
  const [email, setEmail] = useState('')
  const router = useRouter()

  useEffect(() => {
    // Au chargement de la page, on vérifie si quelqu'un est connecté
    const getUser = async () => {
      const { data } = await supabase.auth.getUser()

      if (!data.user) {
        // Personne n'est connecté → on renvoie à la page connexion
        router.push('/connexion')
      } else {
        // Quelqu'un est connecté → on récupère son email
        setEmail(data.user.email ?? '')
      }
    }

    getUser()
  }, [])

  const handleDeconnexion = async () => {
    await supabase.auth.signOut()
    router.push('/')
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 p-6">

      {/* Barre du haut */}
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-indigo-700">🌙 Ephemer</h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-500">{email}</span>
            <button
              onClick={handleDeconnexion}
              className="text-sm bg-white border border-gray-200 text-gray-600 px-4 py-2 rounded-xl hover:bg-red-50 hover:text-red-500 hover:border-red-200 transition"
            >
              Se déconnecter
            </button>
          </div>
        </div>

        {/* Message de bienvenue */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-800">
            Bienvenue sur ton dashboard ! 🎉
          </h2>
          <p className="text-gray-500 mt-1">
            Bientôt tu verras ici tous tes événements à venir.
          </p>
        </div>

        {/* Carte placeholder - Contacts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-2xl shadow-sm p-6 border-2 border-dashed border-indigo-100">
            <div className="text-3xl mb-3">👥</div>
            <h3 className="font-bold text-gray-700">Mes contacts</h3>
            <p className="text-sm text-gray-400 mt-1">Ajoute tes proches pour ne plus rater leurs dates importantes</p>
     <button
  onClick={() => router.push('/contacts/nouveau')}
  className="mt-4 bg-indigo-600 text-white text-sm font-semibold px-4 py-2 rounded-xl hover:bg-indigo-500 transition"
>
  + Ajouter un contact
</button>

          </div>

          {/* Carte placeholder - Événements */}
          <div className="bg-white rounded-2xl shadow-sm p-6 border-2 border-dashed border-purple-100">
            <div className="text-3xl mb-3">📅</div>
            <h3 className="font-bold text-gray-700">Prochains événements</h3>
            <p className="text-sm text-gray-400 mt-1">Aucun événement pour l'instant</p>
          </div>
        </div>

      </div>
    </main>
  )
}
